<?php
// File: app\Models\Book.php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    // Your model code here
}

?>